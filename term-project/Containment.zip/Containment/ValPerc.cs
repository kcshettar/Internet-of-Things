﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IOT_Project
{
    public class ValPerc
    {
        public string val { get; set; }
        public string percent { get; set; }
    }
}
